This code snippet is free for NON-COMMERCIAL use. 
Feel free to adapt / improve it as well.

Copyright 2007-2008 by Marco van Hylckama Vlieg

http://www.i-marco.nl/weblog/
marco@i-marco.nl