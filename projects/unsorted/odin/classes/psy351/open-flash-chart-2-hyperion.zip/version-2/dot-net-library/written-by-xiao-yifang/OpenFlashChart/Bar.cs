using System;
using System.Collections.Generic;
using System.Text;

namespace OpenFlashChart
{
    public class Bar:Chart<double >
    {
        public Bar(){
            this.ChartType = "bar";
        }
        
    }
}
